# OpiumChat - Python Edition

A lightweight peer-to-peer messaging application designed to work on old Macs and modern systems alike. This is the Python implementation of OpiumChat, focused on compatibility with older systems that cannot run Node.js.

## Features

- Peer-to-peer messaging with end-to-end encryption
- Terminal-based interface for maximum compatibility
- WebSocket-based communication for real-time messaging
- Works on old Macs with Python 3 installed
- Local storage of user identity and chat history
- Simple, clean, and minimal interface

## Requirements

- Python 3.7 or higher
- Required packages: `websockets`, `pycryptodome`

## Installation

1. **Clone or download this repository**

2. **Install required packages**:

   ```bash
   pip3 install -r requirements.txt
   ```

3. **Make the Python scripts executable** (optional):

   ```bash
   chmod +x server.py client.py
   ```

## Running OpiumChat

### Starting the Server

The server acts as a signaling mechanism to connect peers:

```bash
python3 server.py
```

By default, the server listens on all interfaces on port 8080.

### Starting the Client

Run the terminal client:

```bash
python3 client.py
```

Follow the prompts to:
- Connect to a server
- Create a user account or login with existing keys
- Start chatting with other online users

## Connecting Two Macs

To connect between two Macs (old and new):

1. **Determine which Mac will run the server**
   
   This could be either Mac, but preferably the one with the more reliable connection.

2. **Find the server Mac's IP address**:
   
   On macOS, run:
   ```bash
   ifconfig | grep "inet " | grep -v 127.0.0.1
   ```
   
   Look for a line like `inet 192.168.1.5` which shows your local IP address.

3. **Start the server** on the designated server Mac:
   
   ```bash
   python3 server.py
   ```

4. **Start the client** on both Macs:
   
   ```bash
   python3 client.py
   ```

5. **Connect to the server**:
   
   - On the server Mac, when prompted, connect to localhost (default option)
   - On the other Mac, when prompted:
     - Choose "n" when asked to connect to localhost
     - Enter the IP address of the server Mac

6. **Create accounts** on both clients when prompted

7. **Start chatting**:
   - Select "Show online users" to see connected users
   - Select "Start a chat" to begin messaging

## Security Notes

- Messages are encrypted end-to-end using AES encryption
- Your identity is based on a public/private key pair
- The server only relays encrypted messages and cannot read content
- Your keys are stored locally on your device
- **IMPORTANT**: Save your keys! They cannot be recovered if lost

## Troubleshooting

### Connection Issues

- **Cannot connect to server**:
  - Verify the server is running
  - Check if port 8080 is blocked by a firewall
  - Confirm you're using the correct IP address

- **"Connection refused" error**:
  - Make sure the server is running
  - Check that you've entered the correct IP address
  - Verify the port is open (8080 by default)

- **Messages not sending**:
  - Ensure both users are connected to the same server
  - Check that you're using the correct public key for the recipient

### Other Issues

- **Python version too old**:
  - OpiumChat requires Python 3.7+
  - Check your Python version with `python3 --version`
  - Consider using pyenv to install a newer Python version

- **Import errors**:
  - Make sure you've installed all dependencies with `pip3 install -r requirements.txt`

## License

This software is open-source and free to use.

---

OpiumChat Python Edition is designed to be minimal, secure, and compatible with older systems. If you encounter any issues not addressed in this README, please check the console output for more detailed error messages.