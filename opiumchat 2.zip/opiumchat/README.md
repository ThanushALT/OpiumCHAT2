# OpiumChat: Minimal P2P Messaging

OpiumChat is a lightweight peer-to-peer messaging application designed to work across any device - including old machines, terminals, and modern computers. This guide will help you set up communication between different Mac devices.

## Table of Contents
- [Requirements](#requirements)
- [Installation](#installation)
- [Running the Server](#running-the-server)
- [Connecting Clients](#connecting-clients)
  - [Terminal Client](#terminal-client)
  - [Web Client](#web-client)
- [Connecting Between Macs](#connecting-between-macs)
- [Troubleshooting](#troubleshooting)
- [Security Notes](#security-notes)

## Requirements

- Node.js (v10.0.0 or higher)
- Basic terminal knowledge
- Network connectivity between devices

## Installation

1. Clone or download this repository to both Macs
2. Navigate to the project directory and install dependencies:

```bash
cd opiumchat
npm install
```

## Running the Server

The signaling server must be running for clients to discover each other:

```bash
npm start
```

This starts the WebSocket server on port 8080. By default, this server runs on localhost, which is only accessible from the same machine.

## Connecting Clients

### Terminal Client

Run the terminal client with:

```bash
npm run client
```

Follow the prompts to create an account or log in with existing keys.

### Web Client

To run the web client, you need to serve the static files in the `public` directory. You can use any HTTP server, but here's a simple option using Node.js:

```bash
npx http-server public
```

Then open a browser and navigate to http://localhost:8080

## Connecting Between Macs

To connect between different Mac computers (old and new):

1. **Run the server on one Mac**:
   Choose one computer to act as the signaling server. This should be the computer with the most reliable connection.

2. **Make sure it's accessible**:
   - The server must be accessible from both devices
   - Find the IP address of the server Mac:
     ```bash
     ifconfig | grep "inet " | grep -v 127.0.0.1
     ```
   - This will show something like `inet 192.168.1.5`

3. **Update client configuration**:
   - On both Macs, edit the client files to use the server's IP address:
   
   For terminal client, edit `client-terminal.js`:
   ```javascript
   // Change this line
   const SERVER_URL = 'ws://localhost:8080';
   // To
   const SERVER_URL = 'ws://192.168.1.5:8080'; // Use your server's IP
   ```
   
   For web client, edit `public/client.js`:
   ```javascript
   // Change this line
   const SERVER_URL = 'ws://' + window.location.hostname + ':8080';
   // To 
   const SERVER_URL = 'ws://192.168.1.5:8080'; // Use your server's IP
   ```

4. **Check firewall settings**:
   - Make sure port 8080 is open on the server Mac
   - On macOS, go to System Preferences → Security & Privacy → Firewall → Firewall Options
   - Allow incoming connections for Node.js applications

5. **Launch clients on both Macs**:
   - Terminal client: `npm run client`
   - Web client: Navigate to http://SERVER_IP:8080 in a browser

## Troubleshooting

### Connection Issues

1. **Cannot connect to server**:
   - Verify the server is running (`npm start`)
   - Confirm you're using the correct IP address
   - Check if port 8080 is already in use (try changing it in `server.js` and all clients)

2. **Clients cannot see each other**:
   - Ensure both clients are connected to the same server
   - Verify network connectivity between devices (try pinging)
   - Check console logs for any errors

3. **Old Mac compatibility issues**:
   - For very old Macs, use Node.js v10 (the minimum supported version)
   - If web client doesn't work, stick with the terminal client

4. **Messages not delivering**:
   - Ensure both users are online
   - Check that you're using the correct public keys
   - Verify encryption is working (check console for decryption errors)

### Common Errors

- **"WebSocket connection failed"**: Check network connectivity and server address
- **"Failed to decrypt message"**: Verify you're using the correct private key
- **"Error loading keys"**: Check file permissions in the `keys` directory

## Security Notes

1. OpiumChat uses basic encryption with CryptoJS
2. Messages are encrypted end-to-end with the recipient's public key
3. Your identity is represented by your public/private key pair
4. **IMPORTANT**: Save your keys! They cannot be recovered if lost
5. The signaling server only relays encrypted messages and cannot read content

---

OpiumChat is designed for simplicity and compatibility across devices. If you encounter any issues not covered here, check the console logs for more detailed error messages.