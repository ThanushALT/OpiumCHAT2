// OpiumChat Web Client

// Configuration
const SERVER_URL = 'ws://' + window.location.hostname + ':8080';
let ws = null;
let currentUser = null;
let activeUsers = [];
let activeChatUser = null;
let chatHistory = {};

// DOM Elements
const loginScreen = document.getElementById('loginScreen');
const chatInterface = document.getElementById('chatInterface');
const usernameInput = document.getElementById('username');
const createAccountBtn = document.getElementById('createAccountBtn');
const keyDisplay = document.getElementById('keyDisplay');
const publicKeyDisplay = document.getElementById('publicKeyDisplay');
const inputPublicKey = document.getElementById('inputPublicKey');
const inputPrivateKey = document.getElementById('inputPrivateKey');
const loginBtn = document.getElementById('loginBtn');
const userListElement = document.getElementById('userList');
const chatHistoryElement = document.getElementById('chatHistory');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const logoutBtn = document.getElementById('logoutBtn');
const currentUsernameElement = document.getElementById('currentUsername');
const chatWithElement = document.getElementById('chatWith');

// Initialize the application
function init() {
    // Check if we have stored keys
    const savedUser = loadUserFromStorage();
    if (savedUser) {
        currentUser = savedUser;
        showChatInterface();
        connectToServer();
    }
    
    // Event listeners
    createAccountBtn.addEventListener('click', createAccount);
    loginBtn.addEventListener('click', login);
    sendBtn.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });
    logoutBtn.addEventListener('click', logout);
}

// Connect to the signaling server
function connectToServer() {
    ws = new WebSocket(SERVER_URL);
    
    ws.onopen = () => {
        console.log('Connected to OpiumChat server');
        if (currentUser) {
            registerWithServer();
        }
    };
    
    ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        
        switch (data.type) {
            case 'users_list':
                activeUsers = data.users;
                updateUserList();
                break;
                
            case 'message':
                const senderId = data.sender;
                const encryptedContent = data.content;
                
                // Try to decrypt with our private key
                try {
                    const decryptedMessage = decryptMessage(
                        encryptedContent,
                        currentUser.privateKey
                    );
                    
                    // Store in chat history
                    if (!chatHistory[senderId]) {
                        chatHistory[senderId] = [];
                    }
                    
                    chatHistory[senderId].push({
                        sender: senderId,
                        content: decryptedMessage,
                        timestamp: data.timestamp,
                        isIncoming: true
                    });
                    
                    // If we're currently chatting with this user, display the message
                    if (activeChatUser === senderId) {
                        displayChatHistory(senderId);
                    }
                } catch (err) {
                    console.error('Failed to decrypt message:', err);
                }
                break;
        }
    };
    
    ws.onclose = () => {
        console.log('Disconnected from server. Attempting to reconnect...');
        setTimeout(connectToServer, 3000);
    };
    
    ws.onerror = (error) => {
        console.error('Connection error:', error);
    };
}

// Register user with the server
function registerWithServer() {
    if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({
            type: 'register',
            publicKey: currentUser.publicKey,
            username: currentUser.username
        }));
    }
}

// Create a new user account
function createAccount() {
    const username = usernameInput.value.trim();
    if (!username) {
        alert('Please enter a username');
        return;
    }
    
    const { privateKey, publicKey } = generateKeyPair();
    
    // Save keys and username
    currentUser = { privateKey, publicKey, username };
    saveUserToStorage(currentUser);
    
    // Display the keys to the user
    publicKeyDisplay.textContent = publicKey;
    keyDisplay.classList.remove('hidden');
    
    // Auto-fill login fields
    inputPublicKey.value = publicKey;
    inputPrivateKey.value = privateKey;
}

// Login with existing keys
function login() {
    const publicKey = inputPublicKey.value.trim();
    const privateKey = inputPrivateKey.value.trim();
    
    if (!publicKey || !privateKey) {
        alert('Please enter both public and private keys');
        return;
    }
    
    currentUser = {
        publicKey,
        privateKey,
        username: publicKey.substring(0, 8) // Use key prefix as username if not provided
    };
    
    saveUserToStorage(currentUser);
    showChatInterface();
    connectToServer();
}

// Logout
function logout() {
    localStorage.removeItem('opiumchat_user');
    currentUser = null;
    ws.close();
    showLoginScreen();
}

// Show the chat interface
function showChatInterface() {
    loginScreen.classList.add('hidden');
    chatInterface.classList.remove('hidden');
    currentUsernameElement.textContent = currentUser.username;
}

// Show the login screen
function showLoginScreen() {
    chatInterface.classList.add('hidden');
    loginScreen.classList.remove('hidden');
}

// Update the user list in the sidebar
function updateUserList() {
    userListElement.innerHTML = '';
    
    if (activeUsers.length === 0) {
        const noUsersElement = document.createElement('div');
        noUsersElement.className = 'user-item';
        noUsersElement.textContent = 'No users online';
        userListElement.appendChild(noUsersElement);
        return;
    }
    
    activeUsers.forEach(userId => {
        const userElement = document.createElement('div');
        userElement.className = 'user-item';
        userElement.textContent = userId.substring(0, 15) + '...';
        
        userElement.addEventListener('click', () => {
            startChat(userId);
        });
        
        userListElement.appendChild(userElement);
    });
}

// Start chat with a specific user
function startChat(userId) {
    activeChatUser = userId;
    chatWithElement.textContent = 'Chatting with: ' + userId.substring(0, 10) + '...';
    messageInput.disabled = false;
    sendBtn.disabled = false;
    messageInput.focus();
    
    displayChatHistory(userId);
}

// Display chat history for a specific user
function displayChatHistory(userId) {
    chatHistoryElement.innerHTML = '';
    
    if (!chatHistory[userId]) {
        return;
    }
    
    chatHistory[userId].forEach(msg => {
        const messageElement = document.createElement('div');
        messageElement.className = 'message ' + (msg.isIncoming ? 'incoming' : 'outgoing');
        messageElement.textContent = msg.content;
        chatHistoryElement.appendChild(messageElement);
    });
    
    // Scroll to bottom
    chatHistoryElement.scrollTop = chatHistoryElement.scrollHeight;
}

// Send a message to the active chat user
function sendMessage() {
    if (!activeChatUser) return;
    
    const message = messageInput.value.trim();
    if (!message) return;
    
    // Encrypt the message with recipient's public key
    const encryptedMessage = encryptMessage(message, activeChatUser);
    
    const timestamp = Date.now();
    
    // Send to server
    ws.send(JSON.stringify({
        type: 'message',
        recipient: activeChatUser,
        content: encryptedMessage,
        timestamp
    }));
    
    // Store in chat history
    if (!chatHistory[activeChatUser]) {
        chatHistory[activeChatUser] = [];
    }
    
    chatHistory[activeChatUser].push({
        sender: currentUser.publicKey,
        content: message,
        timestamp,
        isIncoming: false
    });
    
    // Update UI
    displayChatHistory(activeChatUser);
    messageInput.value = '';
    messageInput.focus();
}

// Cryptography functions
function generateKeyPair() {
    const privateKey = CryptoJS.lib.WordArray.random(32).toString();
    const publicKey = CryptoJS.SHA256(privateKey).toString();
    return { privateKey, publicKey };
}

function encryptMessage(message, publicKey) {
    return CryptoJS.AES.encrypt(message, publicKey).toString();
}

function decryptMessage(encryptedMessage, privateKey) {
    const bytes = CryptoJS.AES.decrypt(encryptedMessage, privateKey);
    return bytes.toString(CryptoJS.enc.Utf8);
}

// Local storage functions
function saveUserToStorage(user) {
    localStorage.setItem('opiumchat_user', JSON.stringify(user));
}

function loadUserFromStorage() {
    const userData = localStorage.getItem('opiumchat_user');
    return userData ? JSON.parse(userData) : null;
}

// Initialize the application
document.addEventListener('DOMContentLoaded', init);
