#!/usr/bin/env python3

import asyncio
import json
import websockets
import os
import sys
import time
import signal
from datetime import datetime
from typing import Dict, List, Optional
from crypto_utils import CryptoUtils

# Terminal colors for better readability
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'

# Configuration
SERVER_URL = "ws://localhost:8080"  # Default to localhost, will be updated by user
current_user = None
active_users = []
active_chat_user = None
chat_history: Dict[str, List[Dict]] = {}

# Terminal UI state
in_chat_mode = False
exit_requested = False

async def connect_to_server():
    """Connect to the OpiumChat server"""
    global SERVER_URL
    
    print(f"{Colors.BOLD}OpiumChat Terminal Client{Colors.ENDC}")
    print("=" * 25)
    
    # Ask for server address if not localhost
    use_local = input("Connect to localhost server? (Y/n): ").lower() != 'n'
    if not use_local:
        ip = input("Enter server IP address: ")
        SERVER_URL = f"ws://{ip}:8080"
    
    print(f"Connecting to {SERVER_URL}...")
    
    try:
        # Create connection to server
        async with websockets.connect(SERVER_URL) as websocket:
            print(f"{Colors.GREEN}Connected to OpiumChat server{Colors.ENDC}")
            
            # Check if we have stored keys
            saved_keys = CryptoUtils.load_keys()
            if saved_keys:
                global current_user
                current_user = saved_keys
                print(f"Logged in as: {current_user['username']}")
                await register_with_server(websocket)
                await show_main_menu()
            else:
                await prompt_create_account(websocket)
            
            # Main message loop
            await message_loop(websocket)
    
    except websockets.exceptions.ConnectionClosed:
        print(f"{Colors.RED}Disconnected from server.{Colors.ENDC}")
        print("Attempting to reconnect in 3 seconds...")
        await asyncio.sleep(3)
        await connect_to_server()
    
    except websockets.exceptions.WebSocketException as e:
        print(f"{Colors.RED}Connection error: {e}{Colors.ENDC}")
        print("Check your network connection and server address.")
        retry = input("Retry connection? (Y/n): ").lower() != 'n'
        if retry:
            await connect_to_server()
    
    except Exception as e:
        print(f"{Colors.RED}Unexpected error: {e}{Colors.ENDC}")

async def message_loop(websocket):
    """Handle incoming messages from the server"""
    global active_users, active_chat_user, in_chat_mode
    
    # Set up task for user input
    input_task = asyncio.create_task(user_input_handler(websocket))
    
    try:
        async for message in websocket:
            data = json.loads(message)
            
            if data["type"] == "users_list":
                active_users = data["users"]
                if not in_chat_mode:
                    await show_main_menu()
            
            elif data["type"] == "message":
                sender_id = data["sender"]
                encrypted_content = data["content"]
                
                # Try to decrypt with our private key
                try:
                    decrypted_message = CryptoUtils.decrypt_message(
                        encrypted_content,
                        current_user["privateKey"]
                    )
                    
                    # Store in chat history
                    if sender_id not in chat_history:
                        chat_history[sender_id] = []
                    
                    chat_history[sender_id].append({
                        "sender": sender_id,
                        "content": decrypted_message,
                        "timestamp": data["timestamp"],
                        "isIncoming": True
                    })
                    
                    # If we're currently chatting with this user, display the message
                    if in_chat_mode and active_chat_user == sender_id:
                        print(f"\n{Colors.BLUE}THEM:{Colors.ENDC} {decrypted_message}")
                    else:
                        print(f"\n{Colors.YELLOW}New message from user: {sender_id[:10]}...{Colors.ENDC}")
                        print("Type 'menu' to return to main menu and view messages")
                
                except Exception as e:
                    print(f"{Colors.RED}Failed to decrypt message: {e}{Colors.ENDC}")
    
    except asyncio.CancelledError:
        input_task.cancel()
        raise
    
    finally:
        input_task.cancel()

async def user_input_handler(websocket):
    """Handle user input based on current UI state"""
    global in_chat_mode, active_chat_user, exit_requested
    
    while not exit_requested:
        if in_chat_mode:
            await handle_chat_input(websocket)
        else:
            await asyncio.sleep(0.1)  # Small delay to prevent CPU hogging

async def register_with_server(websocket):
    """Register user with the server"""
    if websocket.open:
        await websocket.send(json.dumps({
            "type": "register",
            "publicKey": current_user["publicKey"],
            "username": current_user["username"]
        }))

async def prompt_create_account(websocket):
    """Create a new user account"""
    global current_user
    
    username = input("Enter a username: ")
    private_key, public_key = CryptoUtils.generate_key_pair()
    
    # Save keys and username
    current_user = {
        "privateKey": private_key,
        "publicKey": public_key,
        "username": username
    }
    CryptoUtils.save_keys(private_key, public_key, username)
    
    print(f"\n{Colors.BOLD}===== YOUR IDENTITY INFORMATION ====={Colors.ENDC}")
    print(f"Username: {username}")
    print(f"Public Key: {public_key}")
    print(f"{Colors.YELLOW}IMPORTANT: Keep your keys safe. They cannot be recovered!{Colors.ENDC}")
    print("=====================================\n")
    
    await register_with_server(websocket)
    await show_main_menu()

async def show_main_menu():
    """Display main menu"""
    global in_chat_mode
    in_chat_mode = False
    
    print(f"\n{Colors.BOLD}===== OPIUM CHAT MENU ====={Colors.ENDC}")
    print("1. Show online users")
    print("2. Start a chat")
    print("3. View message history")
    print("4. Exit")
    print("===========================")
    
    option = input("Choose an option: ")
    
    if option == "1":
        await show_online_users()
    elif option == "2":
        await start_chat_prompt()
    elif option == "3":
        await view_message_history()
    elif option == "4":
        global exit_requested
        print("Goodbye!")
        exit_requested = True
        sys.exit(0)
    else:
        print("Invalid option")
        await show_main_menu()

async def show_online_users():
    """Show list of online users"""
    print(f"\n{Colors.BOLD}===== ONLINE USERS ====={Colors.ENDC}")
    if not active_users:
        print("No users online")
    else:
        for idx, user_id in enumerate(active_users):
            print(f"{idx + 1}. {user_id[:15]}...")
    print("========================")
    await show_main_menu()

async def start_chat_prompt():
    """Prompt to start a chat"""
    if not active_users:
        print("No users online to chat with")
        await show_main_menu()
        return
    
    print(f"\n{Colors.BOLD}===== CHAT WITH USER ====={Colors.ENDC}")
    for idx, user_id in enumerate(active_users):
        print(f"{idx + 1}. {user_id[:15]}...")
    
    input_val = input("Enter user number or full public key: ")
    
    target_user = None
    
    # Check if input is a number (index)
    try:
        user_index = int(input_val) - 1
        if 0 <= user_index < len(active_users):
            target_user = active_users[user_index]
    except ValueError:
        # Assume it's a public key
        target_user = input_val.strip()
        if target_user not in active_users:
            print("User not found or not online")
            await show_main_menu()
            return
    
    # Start chat with the selected user
    await start_chat(target_user)

async def start_chat(user_id):
    """Start chat with a specific user"""
    global active_chat_user, in_chat_mode
    active_chat_user = user_id
    in_chat_mode = True
    
    print(f"\n{Colors.BOLD}===== CHATTING WITH: {user_id[:10]}... ====={Colors.ENDC}")
    print("Type your messages. Enter 'menu' to return to main menu.\n")
    
    # Show chat history if exists
    if user_id in chat_history:
        for msg in chat_history[user_id][-5:]:  # Show last 5 messages
            if msg["isIncoming"]:
                print(f"{Colors.BLUE}THEM:{Colors.ENDC} {msg['content']}")
            else:
                print(f"{Colors.GREEN}YOU:{Colors.ENDC} {msg['content']}")

async def handle_chat_input(websocket):
    """Handle chat input when in chat mode"""
    global active_chat_user, in_chat_mode
    
    message = input("")
    
    if message.lower() == "menu":
        in_chat_mode = False
        active_chat_user = None
        await show_main_menu()
        return
    
    # Send message to the server
    encrypted_message = CryptoUtils.encrypt_message(
        message,
        active_chat_user
    )
    
    timestamp = int(time.time() * 1000)  # Milliseconds since epoch
    
    await websocket.send(json.dumps({
        "type": "message",
        "recipient": active_chat_user,
        "content": encrypted_message,
        "timestamp": timestamp
    }))
    
    # Store in chat history
    if active_chat_user not in chat_history:
        chat_history[active_chat_user] = []
    
    chat_history[active_chat_user].append({
        "sender": current_user["publicKey"],
        "content": message,
        "timestamp": timestamp,
        "isIncoming": False
    })
    
    # Echo the message to the terminal
    print(f"{Colors.GREEN}YOU:{Colors.ENDC} {message}")

async def view_message_history():
    """View message history"""
    chat_users = list(chat_history.keys())
    
    if not chat_users:
        print("No chat history available")
        await show_main_menu()
        return
    
    print(f"\n{Colors.BOLD}===== MESSAGE HISTORY ====={Colors.ENDC}")
    for idx, user_id in enumerate(chat_users):
        messages_count = len(chat_history[user_id])
        print(f"{idx + 1}. {user_id[:15]}... ({messages_count} messages)")
    
    input_val = input("Select a conversation or press Enter to return: ")
    
    if not input_val:
        await show_main_menu()
        return
    
    try:
        chat_index = int(input_val) - 1
        if 0 <= chat_index < len(chat_users):
            user_id = chat_users[chat_index]
            await start_chat(user_id)
        else:
            print("Invalid selection")
            await view_message_history()
    except ValueError:
        print("Invalid input")
        await view_message_history()

# Handle CTRL+C gracefully
def signal_handler(sig, frame):
    print("\nExiting OpiumChat...")
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

# Start the client
if __name__ == "__main__":
    # Fix for missing datetime import
    from datetime import datetime
    asyncio.run(connect_to_server())
