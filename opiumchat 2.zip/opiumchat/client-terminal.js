const WebSocket = require('ws');
const readline = require('readline');
const fs = require('fs');
const CryptoUtils = require('./crypto-utils');

// Create terminal interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Configuration
const SERVER_URL = 'ws://localhost:8080';
let ws = null;
let currentUser = null;
let activeUsers = [];
let activeChatUser = null;
let chatHistory = {};

// Connect to signaling server
function connectToServer() {
  ws = new WebSocket(SERVER_URL);
  
  ws.on('open', () => {
    console.log('Connected to OpiumChat server');
    
    // Check if we have stored keys
    const savedKeys = CryptoUtils.loadKeys();
    if (savedKeys) {
      currentUser = savedKeys;
      console.log(`Logged in as: ${currentUser.username}`);
      registerWithServer();
      showMainMenu();
    } else {
      promptCreateAccount();
    }
  });
  
  ws.on('message', (message) => {
    const data = JSON.parse(message);
    
    switch (data.type) {
      case 'users_list':
        activeUsers = data.users;
        if (activeChatUser === null) {
          showMainMenu();
        }
        break;
        
      case 'message':
        const senderId = data.sender;
        const encryptedContent = data.content;
        
        // Try to decrypt with our private key
        try {
          const decryptedMessage = CryptoUtils.decryptMessage(
            encryptedContent,
            currentUser.privateKey
          );
          
          // Store in chat history
          if (!chatHistory[senderId]) {
            chatHistory[senderId] = [];
          }
          
          chatHistory[senderId].push({
            sender: senderId,
            content: decryptedMessage,
            timestamp: data.timestamp,
            isIncoming: true
          });
          
          // If we're currently chatting with this user, display the message
          if (activeChatUser === senderId) {
            console.log(`\nTHEM: ${decryptedMessage}`);
          } else {
            console.log(`\nNew message from user: ${senderId.substring(0, 10)}...`);
            console.log('Type "menu" to return to main menu and view messages');
          }
        } catch (err) {
          console.error('Failed to decrypt message:', err);
        }
        break;
    }
  });
  
  ws.on('close', () => {
    console.log('Disconnected from server. Attempting to reconnect...');
    setTimeout(connectToServer, 3000);
  });
  
  ws.on('error', (error) => {
    console.error('Connection error:', error.message);
  });
}

// Register user with server
function registerWithServer() {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({
      type: 'register',
      publicKey: currentUser.publicKey,
      username: currentUser.username
    }));
  }
}

// Create a new user account
function promptCreateAccount() {
  rl.question('Enter a username: ', (username) => {
    const { privateKey, publicKey } = CryptoUtils.generateKeyPair();
    
    // Save keys and username
    currentUser = { privateKey, publicKey, username };
    CryptoUtils.saveKeys(privateKey, publicKey, username);
    
    console.log('\n===== YOUR IDENTITY INFORMATION =====');
    console.log(`Username: ${username}`);
    console.log(`Public Key: ${publicKey}`);
    console.log('IMPORTANT: Keep your keys safe. They cannot be recovered!');
    console.log('=====================================\n');
    
    registerWithServer();
    showMainMenu();
  });
}

// Display main menu
function showMainMenu() {
  console.log('\n===== OPIUM CHAT MENU =====');
  console.log('1. Show online users');
  console.log('2. Start a chat');
  console.log('3. View message history');
  console.log('4. Exit');
  console.log('===========================');
  
  rl.question('Choose an option: ', (option) => {
    switch (option) {
      case '1':
        showOnlineUsers();
        break;
      case '2':
        startChatPrompt();
        break;
      case '3':
        viewMessageHistory();
        break;
      case '4':
        console.log('Goodbye!');
        process.exit(0);
        break;
      default:
        console.log('Invalid option');
        showMainMenu();
    }
  });
}

// Show list of online users
function showOnlineUsers() {
  console.log('\n===== ONLINE USERS =====');
  if (activeUsers.length === 0) {
    console.log('No users online');
  } else {
    activeUsers.forEach((userId, index) => {
      console.log(`${index + 1}. ${userId.substring(0, 15)}...`);
    });
  }
  console.log('========================');
  showMainMenu();
}

// Prompt to start a chat
function startChatPrompt() {
  if (activeUsers.length === 0) {
    console.log('No users online to chat with');
    return showMainMenu();
  }
  
  console.log('\n===== CHAT WITH USER =====');
  activeUsers.forEach((userId, index) => {
    console.log(`${index + 1}. ${userId.substring(0, 15)}...`);
  });
  
  rl.question('Enter user number or full public key: ', (input) => {
    let targetUser;
    
    // Check if input is a number (index)
    const userIndex = parseInt(input) - 1;
    if (!isNaN(userIndex) && userIndex >= 0 && userIndex < activeUsers.length) {
      targetUser = activeUsers[userIndex];
    } else {
      // Assume it's a public key
      targetUser = input.trim();
      if (!activeUsers.includes(targetUser)) {
        console.log('User not found or not online');
        return showMainMenu();
      }
    }
    
    // Start chat with the selected user
    startChat(targetUser);
  });
}

// Start chat with a specific user
function startChat(userId) {
  activeChatUser = userId;
  console.log(`\n===== CHATTING WITH: ${userId.substring(0, 10)}... =====`);
  console.log('Type your messages. Enter "menu" to return to main menu.\n');
  
  // Show chat history if exists
  if (chatHistory[userId]) {
    chatHistory[userId].slice(-5).forEach(msg => {
      if (msg.isIncoming) {
        console.log(`THEM: ${msg.content}`);
      } else {
        console.log(`YOU: ${msg.content}`);
      }
    });
  }
  
  // Message input handler
  const askForMessage = () => {
    rl.question('', (message) => {
      if (message.toLowerCase() === 'menu') {
        activeChatUser = null;
        return showMainMenu();
      }
      
      // Send message to the server
      const encryptedMessage = CryptoUtils.encryptMessage(
        message,
        activeChatUser
      );
      
      const timestamp = Date.now();
      
      ws.send(JSON.stringify({
        type: 'message',
        recipient: activeChatUser,
        content: encryptedMessage,
        timestamp
      }));
      
      // Store in chat history
      if (!chatHistory[activeChatUser]) {
        chatHistory[activeChatUser] = [];
      }
      
      chatHistory[activeChatUser].push({
        sender: currentUser.publicKey,
        content: message,
        timestamp,
        isIncoming: false
      });
      
      askForMessage();
    });
  };
  
  askForMessage();
}

// View message history
function viewMessageHistory() {
  const chatUsers = Object.keys(chatHistory);
  
  if (chatUsers.length === 0) {
    console.log('No chat history available');
    return showMainMenu();
  }
  
  console.log('\n===== MESSAGE HISTORY =====');
  chatUsers.forEach((userId, index) => {
    const unread = chatHistory[userId].filter(msg => msg.isIncoming).length;
    console.log(`${index + 1}. ${userId.substring(0, 15)}... (${chatHistory[userId].length} messages)`);
  });
  
  rl.question('Select a conversation or press Enter to return: ', (input) => {
    if (!input) {
      return showMainMenu();
    }
    
    const chatIndex = parseInt(input) - 1;
    if (!isNaN(chatIndex) && chatIndex >= 0 && chatIndex < chatUsers.length) {
      const userId = chatUsers[chatIndex];
      startChat(userId);
    } else {
      console.log('Invalid selection');
      viewMessageHistory();
    }
  });
}

// Start the client
console.log('OpiumChat Terminal Client');
console.log('=========================');
connectToServer();
