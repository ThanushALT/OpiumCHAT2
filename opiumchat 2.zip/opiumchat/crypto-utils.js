const CryptoJS = require('crypto-js');
const fs = require('fs');
const path = require('path');

// Simple encryption/decryption utility
class CryptoUtils {
  // Generate a new key pair
  static generateKeyPair() {
    const privateKey = CryptoJS.lib.WordArray.random(32).toString();
    const publicKey = CryptoJS.SHA256(privateKey).toString();
    return { privateKey, publicKey };
  }
  
  // Encrypt a message using recipient's public key
  static encryptMessage(message, publicKey) {
    return CryptoJS.AES.encrypt(message, publicKey).toString();
  }
  
  // Decrypt a message using recipient's private key
  static decryptMessage(encryptedMessage, privateKey) {
    const bytes = CryptoJS.AES.decrypt(encryptedMessage, privateKey);
    return bytes.toString(CryptoJS.enc.Utf8);
  }
  
  // Sign a message using sender's private key
  static signMessage(message, privateKey) {
    return CryptoJS.HmacSHA256(message, privateKey).toString();
  }
  
  // Verify a message signature using sender's public key
  static verifySignature(message, signature, publicKey) {
    const computedSignature = CryptoJS.HmacSHA256(message, publicKey).toString();
    return computedSignature === signature;
  }
  
  // Save keys to local storage
  static saveKeys(privateKey, publicKey, username) {
    const keyData = {
      privateKey,
      publicKey,
      username,
      createdAt: new Date().toISOString()
    };
    
    const keysDir = path.join(__dirname, 'keys');
    if (!fs.existsSync(keysDir)) {
      fs.mkdirSync(keysDir);
    }
    
    fs.writeFileSync(
      path.join(keysDir, 'user_keys.json'),
      JSON.stringify(keyData),
      'utf8'
    );
  }
  
  // Load keys from local storage
  static loadKeys() {
    try {
      const keyPath = path.join(__dirname, 'keys', 'user_keys.json');
      if (fs.existsSync(keyPath)) {
        const keyData = JSON.parse(fs.readFileSync(keyPath, 'utf8'));
        return keyData;
      }
    } catch (err) {
      console.error('Error loading keys:', err);
    }
    return null;
  }
}

module.exports = CryptoUtils;
