#!/usr/bin/env python3

import os
import json
import base64
from typing import Dict, Tuple, Optional
from pathlib import Path
from datetime import datetime
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad

class CryptoUtils:
    """Utility class for encryption and key management"""
    
    @staticmethod
    def generate_key_pair() -> Tuple[str, str]:
        """Generate a private/public key pair"""
        # For simplicity, we'll use a random private key and its hash as public key
        private_key = base64.b64encode(get_random_bytes(32)).decode('utf-8')
        
        # Generate public key as hash of private key
        h = SHA256.new()
        h.update(private_key.encode('utf-8'))
        public_key = h.hexdigest()
        
        return private_key, public_key
    
    @staticmethod
    def encrypt_message(message: str, public_key: str) -> str:
        """Encrypt a message using recipient's public key"""
        # Use AES for encryption with the public key as the encryption key
        key = SHA256.new(public_key.encode('utf-8')).digest()
        iv = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        
        # Encrypt and encode
        ciphertext = cipher.encrypt(pad(message.encode('utf-8'), AES.block_size))
        
        # Combine IV and ciphertext and encode to base64
        encrypted_data = base64.b64encode(iv + ciphertext).decode('utf-8')
        return encrypted_data
    
    @staticmethod
    def decrypt_message(encrypted_message: str, private_key: str) -> str:
        """Decrypt a message using recipient's private key"""
        # Derive the same key used for encryption
        key = SHA256.new(private_key.encode('utf-8')).digest()
        
        # Decode from base64
        encrypted_data = base64.b64decode(encrypted_message)
        
        # Extract IV (first 16 bytes) and ciphertext
        iv = encrypted_data[:16]
        ciphertext = encrypted_data[16:]
        
        # Decrypt
        cipher = AES.new(key, AES.MODE_CBC, iv)
        decrypted_data = unpad(cipher.decrypt(ciphertext), AES.block_size)
        
        return decrypted_data.decode('utf-8')
    
    @staticmethod
    def save_keys(private_key: str, public_key: str, username: str) -> bool:
        """Save keys to local storage"""
        key_data = {
            "privateKey": private_key,
            "publicKey": public_key,
            "username": username,
            "createdAt": str(datetime.now())
        }
        
        # Create keys directory if it doesn't exist
        keys_dir = Path("keys")
        keys_dir.mkdir(exist_ok=True)
        
        try:
            with open(keys_dir / "user_keys.json", "w") as f:
                json.dump(key_data, f)
            return True
        except Exception as e:
            print(f"Error saving keys: {e}")
            return False
    
    @staticmethod
    def load_keys() -> Optional[Dict]:
        """Load keys from local storage"""
        keys_file = Path("keys/user_keys.json")
        
        if not keys_file.exists():
            return None
        
        try:
            with open(keys_file, "r") as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading keys: {e}")
            return None
