#!/usr/bin/env python3

import asyncio
import json
import logging
import websockets
from typing import Dict, Set

# Configure logging
logging.basicConfig(
    format="%(asctime)s %(message)s",
    level=logging.INFO,
)

# Store connected clients and their websocket connections
connected_users: Dict[str, websockets.WebSocketServerProtocol] = {}

async def register_user(websocket, user_id):
    """Register a new user with the server"""
    logging.info(f"User registered: {user_id[:10]}...")
    connected_users[user_id] = websocket
    
    # Send the list of users to the new client
    online_users = [uid for uid in connected_users.keys() if uid != user_id]
    await websocket.send(json.dumps({
        "type": "users_list",
        "users": online_users
    }))
    
    # Notify all other users about the new user
    await broadcast_user_list()

async def unregister_user(user_id):
    """Remove a user when they disconnect"""
    if user_id in connected_users:
        logging.info(f"User disconnected: {user_id[:10]}...")
        del connected_users[user_id]
        await broadcast_user_list()

async def broadcast_user_list():
    """Send the updated user list to all connected clients"""
    user_list = list(connected_users.keys())
    
    for client_id, websocket in connected_users.items():
        # Filter out the client's own ID from the list
        filtered_users = [uid for uid in user_list if uid != client_id]
        try:
            await websocket.send(json.dumps({
                "type": "users_list",
                "users": filtered_users
            }))
        except websockets.exceptions.ConnectionClosed:
            pass

async def handle_message(websocket, sender_id, data):
    """Handle incoming messages and relay them to recipients"""
    if data["type"] == "message":
        recipient_id = data["recipient"]
        recipient = connected_users.get(recipient_id)
        
        if recipient and recipient.open:
            # Forward the encrypted message to recipient
            await recipient.send(json.dumps({
                "type": "message",
                "sender": sender_id,
                "content": data["content"],
                "timestamp": data["timestamp"]
            }))
            logging.info(f"Message relayed from {sender_id[:10]}... to {recipient_id[:10]}...")
        else:
            logging.warning(f"Recipient {recipient_id[:10]}... not found or not connected")

async def chat_server(websocket, path):
    """Main WebSocket server handler"""
    user_id = None
    
    try:
        async for message in websocket:
            data = json.loads(message)
            
            if data["type"] == "register":
                user_id = data["publicKey"]
                await register_user(websocket, user_id)
            elif user_id:
                await handle_message(websocket, user_id, data)
    except websockets.exceptions.ConnectionClosed:
        pass
    except json.JSONDecodeError:
        logging.error("Received invalid JSON")
    finally:
        if user_id:
            await unregister_user(user_id)

async def main():
    """Start the WebSocket server"""
    host = "0.0.0.0"  # Listen on all interfaces
    port = 8080
    
    server = await websockets.serve(chat_server, host, port)
    logging.info(f"OpiumChat server running on {host}:{port}")
    
    # Keep the server running indefinitely
    await server.wait_closed()

if __name__ == "__main__":
    asyncio.run(main())
