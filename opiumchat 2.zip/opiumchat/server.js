const WebSocket = require('ws');
const crypto = require('crypto');

// Simple signaling server to connect peers
const wss = new WebSocket.Server({ port: 8080 });
console.log('OpiumChat signaling server running on port 8080');

// Store connected users with their WebSocket connections
const users = new Map();

wss.on('connection', (ws) => {
  let userId = null;

  ws.on('message', (message) => {
    const data = JSON.parse(message);
    
    // Handle different message types
    switch (data.type) {
      case 'register':
        // Register new user with their public key as ID
        userId = data.publicKey;
        users.set(userId, ws);
        console.log(`User registered: ${userId.substring(0, 10)}...`);
        
        // Send list of online users
        const onlineUsers = Array.from(users.keys()).filter(id => id !== userId);
        ws.send(JSON.stringify({
          type: 'users_list',
          users: onlineUsers
        }));
        
        // Notify others about new user
        broadcastUserList();
        break;
        
      case 'message':
        // Forward message to recipient
        const recipient = users.get(data.recipient);
        if (recipient && recipient.readyState === WebSocket.OPEN) {
          recipient.send(JSON.stringify({
            type: 'message',
            sender: userId,
            content: data.content,
            timestamp: data.timestamp
          }));
        }
        break;
    }
  });

  // Handle disconnection
  ws.on('close', () => {
    if (userId) {
      console.log(`User disconnected: ${userId.substring(0, 10)}...`);
      users.delete(userId);
      broadcastUserList();
    }
  });
  
  // Function to broadcast updated user list
  function broadcastUserList() {
    const userList = Array.from(users.keys());
    const message = JSON.stringify({
      type: 'users_list',
      users: userList
    });
    
    users.forEach((clientWs) => {
      if (clientWs.readyState === WebSocket.OPEN) {
        const clientId = getKeyByValue(users, clientWs);
        const filteredUsers = userList.filter(id => id !== clientId);
        clientWs.send(JSON.stringify({
          type: 'users_list',
          users: filteredUsers
        }));
      }
    });
  }
  
  // Helper to get key by value in Map
  function getKeyByValue(map, searchValue) {
    for (let [key, value] of map.entries()) {
      if (value === searchValue) return key;
    }
    return null;
  }
});
